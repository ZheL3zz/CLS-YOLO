import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

# 示例混淆矩阵（你可自行修改）
confusion_matrix = np.array([
    [157, 78, 0],   # Mild
    [70, 296, 83],   # Moderate
    [5, 42, 248]    # Severe
])

labels = ['Mild', 'Moderate', 'Severe']

# 设置图像风格和大小
plt.figure(figsize=(6, 5))
sns.heatmap(confusion_matrix, annot=True, fmt='d', cmap='Blues',
            xticklabels=labels, yticklabels=labels, cbar=False)

plt.xlabel('Predicted Label', fontsize=12)
plt.ylabel('True Label', fontsize=12)
plt.title('Confusion Matrix of YOLOv11 (Severity Level)', fontsize=14)
plt.tight_layout()

# 创建目录并保存图像
save_dir = './results_fig'
os.makedirs(save_dir, exist_ok=True)
save_path = os.path.join(save_dir, 'confusion_matrix_cls_yolo.png')
plt.savefig(save_path, dpi=300)

plt.show()
print(f"✅ 图像已保存至：{save_path}")
